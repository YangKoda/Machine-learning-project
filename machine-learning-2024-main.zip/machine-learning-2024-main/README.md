# Machine Learning Exercises 2024

### The main contributors are:

* Pwint Kuang 

_matriculation number :_ 22207519

* Ibrahim

_matriculation number :_ 22202898


* Don Binoy

_matriculation number :_ 22209158